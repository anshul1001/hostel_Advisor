# React Native Firebase - Quiz App
- Setup Firebase
- Firebase Authentication
- React Navigation
- Firebase Firestore DB
- Select Image from Gallery
- Upload Image to Firebase
- Fetch Quizzes and Play Quiz
## [Part 1 - Youtube](https://www.youtube.com/watch?v=19TuxEyBh6w)
## [Part 2 - Youtube](https://www.youtube.com/watch?v=O-_VzZ-VESI)
## [Part 3 - Youtube](https://www.youtube.com/watch?v=fRwngDiYO_0)

![App UI](thumbnail-part-1.jpeg)
